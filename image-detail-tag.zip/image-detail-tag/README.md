# Image Detail Tag

A Pen created on CodePen.io. Original URL: [https://codepen.io/gaflint/pen/MWGKLMb](https://codepen.io/gaflint/pen/MWGKLMb).

